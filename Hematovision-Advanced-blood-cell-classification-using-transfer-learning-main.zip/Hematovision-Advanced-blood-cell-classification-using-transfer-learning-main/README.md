# Hematovision-Advanced-blood-cell-classification-using-transfer-learning
Hematovision is a deep learning web app that classifies blood cell images (Neutrophils, Lymphocytes, Monocytes, Eosinophils) using transfer learning with CNNs. Built with Python, TensorFlow, and Flask, it offers a simple UI for quick image uploads and instant cell type predictions.
